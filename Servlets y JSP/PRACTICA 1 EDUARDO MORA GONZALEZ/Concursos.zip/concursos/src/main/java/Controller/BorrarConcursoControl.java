package Controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Dao.*;
import Model.*;
import java.io.File;
import java.io.PrintWriter;
import javax.servlet.annotation.WebServlet;

@WebServlet(name = "BorrarConcurso", urlPatterns = {"/BorrarConcurso"})

public class BorrarConcursoControl extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private static final String DIRECTORY = "directorio/";

    public BorrarConcursoControl() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.getWriter().append("Served at: ").append(request.getContextPath());
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        try {
            String id_String = request.getParameter("id_concurso");

            String UPLOAD_DIRECTORY = DIRECTORY + id_String;

            if (id_String.equals("")) {
                request.getRequestDispatcher("/ErrorBorrar.jsp").forward(request, response);
            }

            if (FicherosDao.borrar(id_String) && ConcursosDao.borrar(id_String)) {
                String uploadPath = getServletContext().getRealPath("../../../") + File.separator + UPLOAD_DIRECTORY;
                File f1 = new File(uploadPath);
                File[] files = f1.listFiles();
                for (int i = 0; i < files.length; i++) {
                    if (!files[i].isDirectory()) {

                        files[i].delete();
                    }
                }
                f1.delete();

                request.getRequestDispatcher("/Inicio.jsp").forward(request, response);
            } else {
                request.getRequestDispatcher("/ErrorBorrar.jsp").forward(request, response);
            }
        } finally {
            out.close();
        }
    }

}
