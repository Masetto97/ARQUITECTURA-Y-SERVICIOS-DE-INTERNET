package com.ubu.participar.Beans;

import java.io.Serializable;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import com.ubu.participar.Dao.LoginDAO;
import com.ubu.participar.Util.SessionUtils;

@ManagedBean
@SessionScoped
public class Login implements Serializable {

    private static final long serialVersionUID = 1L;

    public static String uname;
    public static String pwd;
    private String msg;

    public static String id;

    public static String getId() {
        return id;
    }

    public static void setId(String id) {
        Login.id = id;
    }

    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String validateUsernamePassword() {
        boolean valid = LoginDAO.validate(uname, pwd);
        if (valid) {

            HttpSession session = SessionUtils.getSession();
            session.setAttribute("username", uname);
            session.setAttribute("password", pwd);
            return "concursos";
        } else {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,
                    "Nombre de usuario y contrasena incorrectos", "Introduzca su nombre de usuario y contrasena"));
            return "login";
        }
    }

    public String logout() {
        HttpSession session = SessionUtils.getSession();
        session.invalidate();
        return "login";
    }

}
