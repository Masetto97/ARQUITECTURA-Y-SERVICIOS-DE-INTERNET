/**
 * Concurso.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package concursosWS;

public class Concurso  implements java.io.Serializable {
    private java.lang.String bases;

    private int ID_concurso;

    private int ID_usuario;

    private java.lang.String jurado;

    private java.lang.String objetivo;

    private java.lang.String plazo;

    private java.lang.String premios;

    private java.lang.String titulo;

    public Concurso() {
    }

    public Concurso(
           java.lang.String bases,
           int ID_concurso,
           int ID_usuario,
           java.lang.String jurado,
           java.lang.String objetivo,
           java.lang.String plazo,
           java.lang.String premios,
           java.lang.String titulo) {
           this.bases = bases;
           this.ID_concurso = ID_concurso;
           this.ID_usuario = ID_usuario;
           this.jurado = jurado;
           this.objetivo = objetivo;
           this.plazo = plazo;
           this.premios = premios;
           this.titulo = titulo;
    }


    /**
     * Gets the bases value for this Concurso.
     * 
     * @return bases
     */
    public java.lang.String getBases() {
        return bases;
    }


    /**
     * Sets the bases value for this Concurso.
     * 
     * @param bases
     */
    public void setBases(java.lang.String bases) {
        this.bases = bases;
    }


    /**
     * Gets the ID_concurso value for this Concurso.
     * 
     * @return ID_concurso
     */
    public int getID_concurso() {
        return ID_concurso;
    }


    /**
     * Sets the ID_concurso value for this Concurso.
     * 
     * @param ID_concurso
     */
    public void setID_concurso(int ID_concurso) {
        this.ID_concurso = ID_concurso;
    }


    /**
     * Gets the ID_usuario value for this Concurso.
     * 
     * @return ID_usuario
     */
    public int getID_usuario() {
        return ID_usuario;
    }


    /**
     * Sets the ID_usuario value for this Concurso.
     * 
     * @param ID_usuario
     */
    public void setID_usuario(int ID_usuario) {
        this.ID_usuario = ID_usuario;
    }


    /**
     * Gets the jurado value for this Concurso.
     * 
     * @return jurado
     */
    public java.lang.String getJurado() {
        return jurado;
    }


    /**
     * Sets the jurado value for this Concurso.
     * 
     * @param jurado
     */
    public void setJurado(java.lang.String jurado) {
        this.jurado = jurado;
    }


    /**
     * Gets the objetivo value for this Concurso.
     * 
     * @return objetivo
     */
    public java.lang.String getObjetivo() {
        return objetivo;
    }


    /**
     * Sets the objetivo value for this Concurso.
     * 
     * @param objetivo
     */
    public void setObjetivo(java.lang.String objetivo) {
        this.objetivo = objetivo;
    }


    /**
     * Gets the plazo value for this Concurso.
     * 
     * @return plazo
     */
    public java.lang.String getPlazo() {
        return plazo;
    }


    /**
     * Sets the plazo value for this Concurso.
     * 
     * @param plazo
     */
    public void setPlazo(java.lang.String plazo) {
        this.plazo = plazo;
    }


    /**
     * Gets the premios value for this Concurso.
     * 
     * @return premios
     */
    public java.lang.String getPremios() {
        return premios;
    }


    /**
     * Sets the premios value for this Concurso.
     * 
     * @param premios
     */
    public void setPremios(java.lang.String premios) {
        this.premios = premios;
    }


    /**
     * Gets the titulo value for this Concurso.
     * 
     * @return titulo
     */
    public java.lang.String getTitulo() {
        return titulo;
    }


    /**
     * Sets the titulo value for this Concurso.
     * 
     * @param titulo
     */
    public void setTitulo(java.lang.String titulo) {
        this.titulo = titulo;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Concurso)) return false;
        Concurso other = (Concurso) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.bases==null && other.getBases()==null) || 
             (this.bases!=null &&
              this.bases.equals(other.getBases()))) &&
            this.ID_concurso == other.getID_concurso() &&
            this.ID_usuario == other.getID_usuario() &&
            ((this.jurado==null && other.getJurado()==null) || 
             (this.jurado!=null &&
              this.jurado.equals(other.getJurado()))) &&
            ((this.objetivo==null && other.getObjetivo()==null) || 
             (this.objetivo!=null &&
              this.objetivo.equals(other.getObjetivo()))) &&
            ((this.plazo==null && other.getPlazo()==null) || 
             (this.plazo!=null &&
              this.plazo.equals(other.getPlazo()))) &&
            ((this.premios==null && other.getPremios()==null) || 
             (this.premios!=null &&
              this.premios.equals(other.getPremios()))) &&
            ((this.titulo==null && other.getTitulo()==null) || 
             (this.titulo!=null &&
              this.titulo.equals(other.getTitulo())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getBases() != null) {
            _hashCode += getBases().hashCode();
        }
        _hashCode += getID_concurso();
        _hashCode += getID_usuario();
        if (getJurado() != null) {
            _hashCode += getJurado().hashCode();
        }
        if (getObjetivo() != null) {
            _hashCode += getObjetivo().hashCode();
        }
        if (getPlazo() != null) {
            _hashCode += getPlazo().hashCode();
        }
        if (getPremios() != null) {
            _hashCode += getPremios().hashCode();
        }
        if (getTitulo() != null) {
            _hashCode += getTitulo().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Concurso.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://concursosWS/", "concurso"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bases");
        elemField.setXmlName(new javax.xml.namespace.QName("", "bases"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ID_concurso");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ID_concurso"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ID_usuario");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ID_usuario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("jurado");
        elemField.setXmlName(new javax.xml.namespace.QName("", "jurado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("objetivo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "objetivo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("plazo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "plazo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("premios");
        elemField.setXmlName(new javax.xml.namespace.QName("", "premios"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("titulo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "titulo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

	@Override
	public String toString() {
		return "Concurso [bases=" + bases + ", ID_concurso=" + ID_concurso + ", ID_usuario=" + ID_usuario + ", jurado="
				+ jurado + ", objetivo=" + objetivo + ", plazo=" + plazo + ", premios=" + premios + ", titulo=" + titulo +"]";
	}

    
}
