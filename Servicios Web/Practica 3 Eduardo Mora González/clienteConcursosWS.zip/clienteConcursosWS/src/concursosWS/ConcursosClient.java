package concursosWS;

import java.rmi.RemoteException;
import java.util.Arrays;

import javax.xml.rpc.ServiceException;

public class ConcursosClient {
	public static void main(String[] args) {
		Servicios_ServiceLocator locator = new Servicios_ServiceLocator();

		try {
			Servicios_PortType userService = locator.getServiciosPort();

			System.out.println("\nLos ultimos 10 concursos son: \n"
					+ Arrays.toString(userService.consultarUltimos10Concursos()));
			
			System.out.println("\nEl ganador del concurso 1 es : \n"
					+ userService.consultarGanador(1));
			
			System.out.println("\nLos participantes del concurso 2 son: \n"
					+ Arrays.toString(userService.consultarParticipantes(2)));
			
			System.out.println("\nEl numero de participantes del concurso 3 son: \n"
					+ userService.consultarNumeroParticipantes(3));
			
			System.out.println("\nLista de los ultimos concursos son: \n"
					+ Arrays.toString(userService.consultarUltimos10Concursos()));
			
			System.out.println("\nEl ganador del concurso 6 es: \n"
					+ userService.consultarGanador(6));
			
			System.out.println("\nEl historico es: \n"
					+ Arrays.toString(userService.consultar()));

		} catch (ServiceException e) {
			e.printStackTrace();
		} catch (RemoteException e) {
			e.printStackTrace();
		}

	}
}
