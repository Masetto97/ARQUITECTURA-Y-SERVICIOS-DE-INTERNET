package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import Model.Ficheros;

public class FicherosDao {

    public FicherosDao() {
        super();
    }

    public static boolean registrar(Ficheros fichero) {

        try {

            String SQL = "INSERT INTO `concursos`.`ficheros` (`titulo`, `ruta`, `idConcurso`) VALUES (?, ?, ?);";

            Connection con = Conexion.conectar();
            PreparedStatement st;

            st = con.prepareStatement(SQL);
            st.setString(1, fichero.getTitulo());
            st.setString(2, fichero.getRuta());
            st.setString(3, fichero.getID_concurso());

            if (st.executeUpdate() > 0) {
                return true;
            } else {
                return false;
            }

        } catch (SQLException e) {
            return false;
        }
    }

    public static String buscar_ultimo_fichero() {
        String id = "";
        try {
            String SQL = "Select * from `concursos`.`ficheros` WHERE ruta = ?;";

            Connection con = Conexion.conectar();
            PreparedStatement st;
            st = con.prepareStatement(SQL);
            st.setString(1, id);

            System.out.print(st.toString());

            ResultSet resultado = st.executeQuery();
            while (resultado.next()) {

                id = resultado.getString("idConcurso");

            }

            return id;
        } catch (SQLException e) {
            return id;
        }
    }

    public static boolean Modificar_Concurso(Ficheros fichero, String id) {

        try {

            String SQL = " UPDATE `concursos`.`ficheros` SET `titulo` = ? , `ruta`= ?,`idConcurso`= ? WHERE idConcurso = ?;";

            Connection con = Conexion.conectar();
            PreparedStatement st;

            st = con.prepareStatement(SQL);
            st.setString(1, fichero.getTitulo());
            st.setString(2, fichero.getRuta());
            st.setString(3, fichero.getID_concurso());
            st.setString(4, id);

            System.out.print(st.toString());

            if (st.executeUpdate() > 0) {
                return true;
            } else {
                return false;
            }

        } catch (SQLException e) {
            return false;
        }
    }

    public static Ficheros obtener_fichero(String id) {

        String ID_fichero;
        String titulo;
        String ruta;
        String ID_Concurso;

        try {

            String SQL = "Select * from `concursos`.`ficheros` where idConcurso = ?;";

            Connection con = Conexion.conectar();
            PreparedStatement st;

            st = con.prepareStatement(SQL);
            st.setString(1, id);
            ResultSet resultado = st.executeQuery();

            Ficheros fichero = null;

            System.out.print(st.toString());

            while (resultado.next()) {

                ID_fichero = resultado.getString("id");
                titulo = resultado.getString("titulo");
                ruta = resultado.getString("ruta");
                ID_Concurso = resultado.getString("idConcurso");

                fichero = new Ficheros(titulo, ruta, ID_Concurso);
                fichero.setID_concurso(ID_Concurso);

            }

            return fichero;

        } catch (SQLException e) {
            return null;
        }

    }

    public static boolean borrar(String id) {

        try {

            String SQL = "DELETE FROM `concursos`.`ficheros` WHERE idConcurso = ?;";

            Connection con = Conexion.conectar();
            PreparedStatement st;
            st = con.prepareStatement(SQL);
            st.setString(1, id);

            System.out.print(st.toString());
            if (st.executeUpdate() > 0) {
                return true;
            } else {
                return false;
            }

        } catch (SQLException e) {
            return false;
        }

    }

    public static ArrayList<Ficheros> listar() {

        String ID;
        String titulo;
        String ruta;
        String concurso;

        try {

            String SQL = "Select * from `concursos`.`ficheros`;";

            Connection con = Conexion.conectar();
            PreparedStatement st;

            st = con.prepareStatement(SQL);

            ResultSet resultado = st.executeQuery();

            ArrayList<Ficheros> lista = new ArrayList();
            Ficheros ficheros;

            System.out.print(st.toString());

            while (resultado.next()) {

                ID = resultado.getString("id");
                titulo = resultado.getString("titulo");
                ruta = resultado.getString("ruta");
                concurso = resultado.getString("idConcurso");

                ficheros = new Ficheros(titulo, ruta, concurso);
                ficheros.setID_concurso(ID);

                lista.add(ficheros);
            }
            return lista;

        } catch (SQLException e) {
            return null;
        }

    }

}
