package Model;

import java.io.Serializable;

public class Ficheros implements Serializable {

    private String ID_fichero;
    private String titulo;
    private String ruta;
    private String ID_concurso;

    public Ficheros(String titulo, String ruta, String iD_concurso) {
        this.titulo = titulo;
        this.ruta = ruta;
        ID_concurso = iD_concurso;
    }

    public Ficheros(String titulo, String ruta) {
        this.titulo = titulo;
        this.ruta = ruta;

    }

    public Ficheros() {
        this.titulo = "";
        this.ruta = "";
        ID_concurso = "";
    }

    public String getID_fichero() {
        return ID_fichero;
    }

    public void setID_fichero(String iD_fichero) {
        ID_fichero = iD_fichero;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getRuta() {
        return ruta;
    }

    public void setRuta(String ruta) {
        this.ruta = ruta;
    }

    public String getID_concurso() {
        return ID_concurso;
    }

    public void setID_concurso(String iD_concurso) {
        ID_concurso = iD_concurso;
    }

    @Override
    public String toString() {
        return "Ficheros{" + "ID_fichero=" + ID_fichero + ", titulo=" + titulo + ", ruta=" + ruta + ", ID_concurso=" + ID_concurso + '}';
    }

}
