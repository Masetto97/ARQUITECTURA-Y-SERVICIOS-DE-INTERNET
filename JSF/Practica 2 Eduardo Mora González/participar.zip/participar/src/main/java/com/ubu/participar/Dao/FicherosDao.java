/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ubu.participar.Dao;

import com.ubu.participar.Beans.FileDownloadBean;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author HP Pavilion
 */
public class FicherosDao {

    public static boolean registrar(String titulo, String ruta, String id) {

        try {

            String SQL = "INSERT INTO participar.fichparticipaciones (`titulo`, `ruta`, `idParticipacion`) VALUES (?, ?, ?);";

            Connection con = DataConnect.getConnection();
            PreparedStatement st;

            st = con.prepareStatement(SQL);
            st.setString(1, titulo);
            st.setString(2, ruta);
            st.setString(3, id);

            System.out.print(st.toString());

            if (st.executeUpdate() > 0) {
                return true;
            } else {
                return false;
            }

        } catch (SQLException e) {
            return false;
        }
    }

    public static String ObtenerFichero(String id) {

        String ruta = "";
        try {

            String SQL = "Select * from participar.fichparticipaciones";

            Connection con = DataConnect.getConnection();
            PreparedStatement st;

            st = con.prepareStatement(SQL);
            ResultSet resultado = st.executeQuery();

            System.out.print(st.toString());

            while (resultado.next()) {
                ruta = resultado.getString("ruta");
            }
            return ruta;
        } catch (SQLException e) {
            return ruta;
        }

    }

    public static ArrayList<FileDownloadBean> listar(String usuario_id) {

        String ID_fichero;
        String titulo;

        try {

            String SQL = "Select id, titulo from `participar`.`fichparticipaciones` where idParticipacion = ?;";

            Connection con = DataConnect.getConnection();
            PreparedStatement st;

            st = con.prepareStatement(SQL);
            st.setString(1, usuario_id);

            ResultSet resultado = st.executeQuery();

            ArrayList<FileDownloadBean> lista = new ArrayList();
            FileDownloadBean fichero;

            System.out.print(st.toString());
            while (resultado.next()) {

                ID_fichero = resultado.getString("id");
                titulo = resultado.getString("titulo");

                fichero = new FileDownloadBean(ID_fichero, titulo);

                lista.add(fichero);
            }
            return lista;

        } catch (SQLException e) {
            return null;
        }

    }

}
