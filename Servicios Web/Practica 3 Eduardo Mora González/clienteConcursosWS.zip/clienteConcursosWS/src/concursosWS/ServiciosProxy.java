package concursosWS;

public class ServiciosProxy implements concursosWS.Servicios_PortType {
  private String _endpoint = null;
  private concursosWS.Servicios_PortType servicios_PortType = null;
  
  public ServiciosProxy() {
    _initServiciosProxy();
  }
  
  public ServiciosProxy(String endpoint) {
    _endpoint = endpoint;
    _initServiciosProxy();
  }
  
  private void _initServiciosProxy() {
    try {
      servicios_PortType = (new concursosWS.Servicios_ServiceLocator()).getServiciosPort();
      if (servicios_PortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)servicios_PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)servicios_PortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (servicios_PortType != null)
      ((javax.xml.rpc.Stub)servicios_PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public concursosWS.Servicios_PortType getServicios_PortType() {
    if (servicios_PortType == null)
      _initServiciosProxy();
    return servicios_PortType;
  }
  
  public concursosWS.Concurso[] consultarUltimos10Concursos() throws java.rmi.RemoteException{
    if (servicios_PortType == null)
      _initServiciosProxy();
    return servicios_PortType.consultarUltimos10Concursos();
  }
  
  public concursosWS.Concurso[] consultarConcursosActivos(java.util.Calendar arg0, java.util.Calendar arg1) throws java.rmi.RemoteException{
    if (servicios_PortType == null)
      _initServiciosProxy();
    return servicios_PortType.consultarConcursosActivos(arg0, arg1);
  }
  
  public int consultarNumeroParticipantes(int idConcurso) throws java.rmi.RemoteException{
    if (servicios_PortType == null)
      _initServiciosProxy();
    return servicios_PortType.consultarNumeroParticipantes(idConcurso);
  }
  
  public concursosWS.Participacion[] consultarParticipantes(int arg0) throws java.rmi.RemoteException{
    if (servicios_PortType == null)
      _initServiciosProxy();
    return servicios_PortType.consultarParticipantes(arg0);
  }
  
  public java.lang.String[] consultar() throws java.rmi.RemoteException{
    if (servicios_PortType == null)
      _initServiciosProxy();
    return servicios_PortType.consultar();
  }
  
  public java.lang.String consultarGanador(int arg0) throws java.rmi.RemoteException{
    if (servicios_PortType == null)
      _initServiciosProxy();
    return servicios_PortType.consultarGanador(arg0);
  }
  
  public concursosWS.Concurso consultarConcursoConMasParticipantes() throws java.rmi.RemoteException{
    if (servicios_PortType == null)
      _initServiciosProxy();
    return servicios_PortType.consultarConcursoConMasParticipantes();
  }
  
  
}