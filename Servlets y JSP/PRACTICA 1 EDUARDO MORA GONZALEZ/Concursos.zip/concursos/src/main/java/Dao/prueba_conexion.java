/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Model.Concursos;
import Model.Ficheros;
import Model.Usuarios;
import java.util.ArrayList;

/**
 *
 * @author HP Pavilion
 */
public class prueba_conexion {

    public static void main(String[] args) {
        Conexion cn = new Conexion();
        cn.conectar();
          UsuariosDao prueba = new UsuariosDao();
        //   Usuarios user = new Usuarios("PASCUAL","PASCUAL","PRUEBA");

        //    boolean exito=  prueba.registrar(user);
        // boolean exito = prueba.consultar("EDU", "EDU");
        // System.out.print("\n\n HE TENIDO EXITO AL REGISTRAR: " + exito);
        //String titulo, String objetivo, String bases, String premios, String plazo,   String jurado, int iD_usuario
      //  ConcursosDao prueba = new ConcursosDao();
       // Concursos cont = new Concursos("e", "e", "e", "e", "e", "e", "1");
       //   boolean exito = prueba.registrar(cont);
       //  System.out.print("\n\n HE TENIDO EXITO AL REGISTRAR: " + exito);

       // ArrayList<Concursos> Concurso = new ArrayList<Concursos>();

       // Concurso = prueba.listar();

      //  for (Concursos con : Concurso) {

         //   System.out.print("\n\n"+con.getID_concurso() + " " + con.getTitulo() + " " + con.getPremios() +"\n");
       // }
       
      //  boolean exito = prueba.borrar("5");
       // System.out.print("\n\n HE TENIDO EXITO AL BORRAR: " + exito);
       
     //  FicherosDao prueba = new FicherosDao();
       // Ficheros cont = new Ficheros("fichero numero","turita", "1");
       
    //    boolean exito = prueba.registrar(cont);
    String id = prueba.obtener_id("edu");
       System.out.print("¿exito? ------------------------------------------------------> "+id);
    }
}
