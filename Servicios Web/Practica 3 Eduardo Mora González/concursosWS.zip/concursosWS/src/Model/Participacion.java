package Model;

public class Participacion {

	private String ID_Participante;
	private String titulo;
	private String descripcion;
	private String apodo;
	private String ID_concurso;
	private String ID_usuario;
	private String votos;

	public Participacion() {
		this.ID_Participante = "";
		this.titulo = "";
		this.descripcion = "";
		this.apodo = "";
		this.ID_concurso = "";
		this.ID_usuario = "";
		this.votos = "";

	}

	public Participacion(String ID_Participante, String titulo, String descripcion, String apodo, String ID_concurso,
			String ID_usuario, String votos) {
		this.ID_Participante = ID_Participante;
		this.titulo = titulo;
		this.descripcion = descripcion;
		this.apodo = apodo;
		this.ID_concurso = ID_concurso;
		this.ID_usuario = ID_usuario;
		this.votos = votos;

	}

	public String getID_Participante() {
		return ID_Participante;
	}

	public void setID_Participante(String ID_Participante) {
		this.ID_Participante = ID_Participante;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getApodo() {
		return apodo;
	}

	public void setApodo(String apodo) {
		this.apodo = apodo;
	}

	public String getID_concurso() {
		return ID_concurso;
	}

	public void setID_concurso(String ID_concurso) {
		this.ID_concurso = ID_concurso;
	}

	public String getID_usuario() {
		return ID_usuario;
	}

	public void setID_usuario(String ID_usuario) {
		this.ID_usuario = ID_usuario;
	}

	public String getVotos() {
		return votos;
	}

	public void setVotos(String votos) {
		this.votos = votos;
	}

	@Override
	public String toString() {
		return "Participar{" + "ID_Participante=" + ID_Participante + ", titulo=" + titulo + ", descripcion="
				+ descripcion + ", apodo=" + apodo + ", ID_concurso=" + ID_concurso + ", ID_usuario=" + ID_usuario
				+ ", votos=" + votos + '}';
	}

}
