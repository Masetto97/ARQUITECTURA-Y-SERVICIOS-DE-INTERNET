package com.ubu.participar.Dao;

import java.util.ArrayList;
import com.ubu.participar.Beans.concursos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ConcursosDao {

    public ConcursosDao() {
        super();
    }

    public static ArrayList<concursos> listar() {

        String ID_concurso;
        String titulo;
        String objetivo;
        String bases;
        String premios;
        String plazo;
        String jurado;
        String ID_usuario;

        try {

            String SQL = "Select * from `participar`.`concursos`;";

            Connection con = DataConnect.getConnection();
            PreparedStatement st;

            st = con.prepareStatement(SQL);

            ResultSet resultado = st.executeQuery();

            ArrayList<concursos> lista = new ArrayList();
            concursos concurso;

            System.out.print(st.toString());
            while (resultado.next()) {

                ID_concurso = resultado.getString("id");
                titulo = resultado.getString("titulo");
                objetivo = resultado.getString("objetivo");
                bases = resultado.getString("bases");
                premios = resultado.getString("premios");
                plazo = resultado.getString("plazo");
                jurado = resultado.getString("jurado");
                ID_usuario = resultado.getString("idUsuario");

                concurso = new concursos(titulo, objetivo, bases, premios, plazo, jurado, ID_usuario);
                concurso.setID_concurso(ID_concurso);

                lista.add(concurso);
            }
            return lista;

        } catch (SQLException e) {
            return null;
        }

    }

    public static boolean existe(String id) {
        try {
            String SQL = "Select * from `participar`.`concursos` WHERE id = ?;";

            Connection con = DataConnect.getConnection();
            PreparedStatement st;
            st = con.prepareStatement(SQL);
            st.setString(1, id);

            System.out.print(st.toString());

            ResultSet rs = st.executeQuery();
            if (rs.next()) {

                return true;
            } else {
                return false;
            }

        } catch (SQLException e) {
            return false;

        }
    }

}
