package Controller;

import Dao.ConcursosDao;
import Dao.FicherosDao;
import Dao.UsuariosDao;
import Model.Concursos;
import Model.Ficheros;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author HP Pavilion
 */
@WebServlet(name = "ConcursoNuevoControl", urlPatterns = {"/ConcursoNuevoControl"})
public class ConcursoNuevoControl extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.getWriter().append("Served at: ").append(request.getContextPath());
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        try {
            String Titulo = request.getParameter("Titulo");
            String Objetivo = request.getParameter("Objetivo");
            String Bases = request.getParameter("Bases");
            String Premios = request.getParameter("Premios");
            String Plazo = request.getParameter("Plazo");
            String Jurado = request.getParameter("Jurado");
            String Usuario = request.getParameter("Usuario");
            String NombreArchivo = request.getParameter("NombreFichero");
            
            String ID_user = UsuariosDao.obtener_id(Usuario);

            Concursos concurso = new Concursos(Titulo, Objetivo, Bases, Premios, Plazo, Jurado, ID_user);

            if (ConcursosDao.registrar(concurso)) {

                String busqueda = ConcursosDao.buscar_concurso(Titulo);
                Ficheros fichero = new Ficheros();
                fichero.setTitulo(NombreArchivo);
                fichero.setID_concurso(busqueda);
                System.out.print(FicherosDao.registrar(fichero));
                request.getRequestDispatcher("/SubirArchivo.jsp").forward(request, response);
            } else {
                request.getRequestDispatcher("/ErrorModificar.jsp").forward(request, response);
            }
        } finally {
            out.close();
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
