package Model;

import java.io.Serializable;

public class Concursos implements Serializable {

    private String ID_concurso;
    private String titulo;
    private String objetivo;
    private String bases;
    private String premios;
    private String plazo;
    private String jurado;
    private String ID_usuario;

    public Concursos() {
        this.titulo = "";
        this.objetivo = "";
        this.bases = "";
        this.premios = "";
        this.plazo = "";
        this.jurado = "";
        ID_usuario = "";
    }

    public Concursos(String titulo, String objetivo, String bases, String premios, String plazo,
            String jurado, String iD_usuario) {
        this.titulo = titulo;
        this.objetivo = objetivo;
        this.bases = bases;
        this.premios = premios;
        this.plazo = plazo;
        this.jurado = jurado;
        ID_usuario = iD_usuario;
    }

    public String getID_concurso() {
        return ID_concurso;
    }

    public void setID_concurso(String iD_concurso) {
        ID_concurso = iD_concurso;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getObjetivo() {
        return objetivo;
    }

    public void setObjetivo(String objetivo) {
        this.objetivo = objetivo;
    }

    public String getBases() {
        return bases;
    }

    public void setBases(String bases) {
        this.bases = bases;
    }

    public String getPremios() {
        return premios;
    }

    public void setPremios(String premios) {
        this.premios = premios;
    }

    public String getPlazo() {
        return plazo;
    }

    public void setPlazo(String plazo) {
        this.plazo = plazo;
    }

    public String getJurado() {
        return jurado;
    }

    public void setJurado(String jurado) {
        this.jurado = jurado;
    }

    public String getID_usuario() {
        return ID_usuario;
    }

    public void setID_usuario(String iD_usuario) {
        ID_usuario = iD_usuario;
    }

    @Override
    public String toString() {
        return "Concursos{" + "ID_concurso=" + ID_concurso + ", titulo=" + titulo + ", objetivo=" + objetivo + ", bases=" + bases + ", premios=" + premios + ", plazo=" + plazo + ", jurado=" + jurado + ", ID_usuario=" + ID_usuario + '}';
    }

}
