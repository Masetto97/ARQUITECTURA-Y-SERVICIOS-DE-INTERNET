package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {

    private static final String CONTROLADOR = "com.mysql.cj.jdbc.Driver";
    private static final String URL = "jdbc:mysql://localhost:3306/participar";
    private static final String USUARIO = "root";
    private static final String CONTRASENA = "";

    static {
        try {
            Class.forName(CONTROLADOR);
        } catch (ClassNotFoundException e) {
            System.out.println("ERROR AL CARGAR LA CONEXION");
            e.printStackTrace();
        }
    }

    public static Connection conectar() {

        Connection conexion = null;

        try {
            conexion = DriverManager.getConnection(URL, USUARIO, CONTRASENA);

            System.out.println("CONEXION OK");

        } catch (SQLException e) {

            System.out.println("ERROR EN LA CONEXION");
            e.printStackTrace();
        }

        return conexion;
    }

}
