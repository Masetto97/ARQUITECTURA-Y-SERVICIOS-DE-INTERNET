package Dao;

import java.util.ArrayList;
import Model.Concursos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ConcursosDao {

    public ConcursosDao() {
        super();
    }

    public static boolean registrar(Concursos concursos) {

        try {

            String SQL = "INSERT INTO `concursos`.`concursos` (`titulo`, `objetivo`,`bases`, `premios`, `plazo`,`jurado`, `idUsuario`) VALUES (?, ?, ?, ?, ?, ?, ?);";

            Connection con = Conexion.conectar();
            PreparedStatement st;

            st = con.prepareStatement(SQL);
            st.setString(1, concursos.getTitulo());
            st.setString(2, concursos.getObjetivo());
            st.setString(3, concursos.getBases());
            st.setString(4, concursos.getPremios());
            st.setString(5, concursos.getPlazo());
            st.setString(6, concursos.getJurado());
            st.setString(7, concursos.getID_usuario());

            System.out.print(st.toString());
            if (st.executeUpdate() > 0) {
                return true;
            } else {
                return false;
            }

        } catch (SQLException e) {
            return false;
        }
    }

    public static ArrayList<Concursos> listar() {

        String ID_concurso;
        String titulo;
        String objetivo;
        String bases;
        String premios;
        String plazo;
        String jurado;
        String ID_usuario;

        try {

            String SQL = "Select * from `concursos`.`concursos`;";

            Connection con = Conexion.conectar();
            PreparedStatement st;

            st = con.prepareStatement(SQL);

            ResultSet resultado = st.executeQuery();

            ArrayList<Concursos> lista = new ArrayList();
            Concursos concurso;

            System.out.print(st.toString());
            while (resultado.next()) {

                ID_concurso = resultado.getString("id");
                titulo = resultado.getString("titulo");
                objetivo = resultado.getString("objetivo");
                bases = resultado.getString("bases");
                premios = resultado.getString("premios");
                plazo = resultado.getString("plazo");
                jurado = resultado.getString("jurado");
                ID_usuario = resultado.getString("idUsuario");

                concurso = new Concursos(titulo, objetivo, bases, premios, plazo, jurado, ID_usuario);
                concurso.setID_concurso(ID_concurso);

                lista.add(concurso);
            }
            return lista;

        } catch (SQLException e) {
            return null;
        }

    }

    public static boolean borrar(String id) {

        try {

            String SQL = "DELETE FROM `concursos`.`concursos` WHERE ID = ?;";

            Connection con = Conexion.conectar();
            PreparedStatement st;
            st = con.prepareStatement(SQL);
            st.setString(1, id);

            System.out.print(st.toString());
            if (st.executeUpdate() > 0) {
                return true;
            } else {
                return false;
            }

        } catch (SQLException e) {
            return false;
        }

    }

    public static boolean Modificar_Concurso(Concursos concurso, String id) {

        try {

            String SQL = " UPDATE `concursos`.`concursos` SET `titulo` = ? , `objetivo`= ?,`bases`= ?, `premios`= ?, `plazo`= ?,`jurado`= ?, `idUsuario`= ? WHERE ID = ?;";

            Connection con = Conexion.conectar();
            PreparedStatement st;

            st = con.prepareStatement(SQL);
            st.setString(1, concurso.getTitulo());
            st.setString(2, concurso.getObjetivo());
            st.setString(3, concurso.getBases());
            st.setString(4, concurso.getPremios());
            st.setString(5, concurso.getPlazo());
            st.setString(6, concurso.getJurado());
            st.setString(7, concurso.getID_usuario());
            st.setString(8, id);

            System.out.print(st.toString());

            if (st.executeUpdate() > 0) {
                return true;
            } else {
                return false;
            }

        } catch (SQLException e) {
            return false;
        }

    }

    public static String buscar_concurso(String titulo) {
        String id = "";
        try {
            String SQL = "Select * from `concursos`.`concursos` WHERE titulo = ?;";

            Connection con = Conexion.conectar();
            PreparedStatement st;
            st = con.prepareStatement(SQL);
            st.setString(1, titulo);

            System.out.print(st.toString());

            ResultSet resultado = st.executeQuery();
            while (resultado.next()) {

                id = resultado.getString("id");

            }

            return id;
        } catch (SQLException e) {
            return id;
        }
    }
}
