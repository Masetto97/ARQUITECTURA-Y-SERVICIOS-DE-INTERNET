package com.ubu.participar.Beans;

import static com.ubu.participar.Beans.Login.id;
import static com.ubu.participar.Beans.concursos.seleccion;
import com.ubu.participar.Dao.FicherosDao;
import com.ubu.participar.Util.SessionUtils;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Scanner;
import javax.servlet.http.Part;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

@Named(value = "fileUploadBean")
@RequestScoped
public class FileUploadBean {

    private Part uploadedFile;
    private String text;
    private String titulo;
    private String filename;

    public FileUploadBean() {
    }

    public void upload() {

        if (null != uploadedFile) {
            try {
                InputStream is = uploadedFile.getInputStream();
                text = new Scanner(is).useDelimiter("\\A").next();
                filename = obtenerNombreFichero(uploadedFile);

                int pos = filename.lastIndexOf(92);
                if (pos > 0) {
                    titulo = filename.substring(pos + 1, filename.length());
                }

                copyFile(filename);

            } catch (IOException ex) {
            }
        }
    }

    private String obtenerNombreFichero(Part part) {
        String cabecera = part.getHeader("content-disposition");
        for (String cd : cabecera.split(";")) {
            if (cd.trim().startsWith("filename")) {
                return cd.substring(cd.indexOf('=') + 1).trim()
                        .replace("\"", "");
            }
        }
        return null;
    }

    public boolean copyFile(String fromFile) {

        ServletContext servletContext = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        String s = (String) servletContext.getRealPath("/");
        String ruta = s + "/directorio/"
                + concursos.seleccion + "/"
                + Crear.ID_Part + "/"
                + titulo;

        File origin = new File(fromFile);
        File destination = new File(ruta);

        if (origin.exists() && FicherosDao.registrar(titulo, ruta, Crear.ID_Part)) {
            try {
                InputStream in = new FileInputStream(origin);
                OutputStream out = new FileOutputStream(destination);
                // We use a buffer for the copy (Usamos un buffer para la copia).
                byte[] buf = new byte[1024];
                int len;
                while ((len = in.read(buf)) > 0) {
                    out.write(buf, 0, len);
                }
                in.close();
                out.close();

                return true;
            } catch (IOException ioe) {
                ioe.printStackTrace();
                return false;
            }
        } else {
            return false;
        }
    }

    public Part getUploadedFile() {
        return uploadedFile;
    }

    public void setUploadedFile(Part uploadedFile) {
        this.uploadedFile = uploadedFile;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

}
