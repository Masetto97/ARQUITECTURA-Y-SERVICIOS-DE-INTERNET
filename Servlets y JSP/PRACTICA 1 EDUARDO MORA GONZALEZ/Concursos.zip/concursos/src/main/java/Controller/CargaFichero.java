package Controller;

import Dao.FicherosDao;
import Model.Ficheros;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

/**
 * Servlet implementation class UploadServlet
 */
@WebServlet(name = "UploadServlet", urlPatterns = {"/UploadServlet"})
public class CargaFichero extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private static final String DIRECTORY = "directorio/";

    private static final int MEMORY_THRESHOLD = 1024 * 1024 * 3;  // 3MB
    private static final int MAX_FILE_SIZE = 1024 * 1024 * 40; // 40MB
    private static final int MAX_REQUEST_SIZE = 1024 * 1024 * 50; // 50MB

    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {

        if (!ServletFileUpload.isMultipartContent(request)) {

            PrintWriter writer = response.getWriter();
            writer.println("Error:  enctype=multipart/form-data");
            writer.flush();
            return;
        }

        Ficheros fichero = null;
        String id = FicherosDao.buscar_ultimo_fichero();
        fichero = FicherosDao.obtener_fichero(id);
        String UPLOAD_DIRECTORY = DIRECTORY + id;

        DiskFileItemFactory factory = new DiskFileItemFactory();

        factory.setSizeThreshold(MEMORY_THRESHOLD);

        factory.setRepository(new File(System.getProperty("java.io.tmpdir")));

        ServletFileUpload upload = new ServletFileUpload(factory);

        upload.setFileSizeMax(MAX_FILE_SIZE);

        upload.setSizeMax(MAX_REQUEST_SIZE);

        String uploadPath = getServletContext().getRealPath("../../../") + File.separator + UPLOAD_DIRECTORY;

        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) {
            uploadDir.mkdir();
            System.out.print(uploadDir.toString());
        }

        try {

            @SuppressWarnings("unchecked")
            List<FileItem> formItems = upload.parseRequest(request);

            if (formItems != null && formItems.size() > 0) {

                for (FileItem item : formItems) {

                    if (!item.isFormField()) {
                        String fileName = new File(item.getName()).getName();
                        String filePath = uploadPath + File.separator + fileName;
                        File storeFile = new File(filePath);

                        System.out.println(filePath);
                        item.write(storeFile);
                        fichero.setRuta(filePath);
                    }
                }
            }
        } catch (Exception ex) {
            request.setAttribute("message", "error: " + ex.getMessage());
        }

        getServletContext().getRequestDispatcher("/Inicio.jsp").forward(
                request, response);

    }
}
