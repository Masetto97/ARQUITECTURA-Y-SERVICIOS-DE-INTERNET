/**
 * Servicios_PortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package concursosWS;

public interface Servicios_PortType extends java.rmi.Remote {
    public concursosWS.Concurso[] consultarUltimos10Concursos() throws java.rmi.RemoteException;
    public concursosWS.Concurso[] consultarConcursosActivos(java.util.Calendar arg0, java.util.Calendar arg1) throws java.rmi.RemoteException;
    public int consultarNumeroParticipantes(int idConcurso) throws java.rmi.RemoteException;
    public concursosWS.Participacion[] consultarParticipantes(int arg0) throws java.rmi.RemoteException;
    public java.lang.String[] consultar() throws java.rmi.RemoteException;
    public java.lang.String consultarGanador(int arg0) throws java.rmi.RemoteException;
    public concursosWS.Concurso consultarConcursoConMasParticipantes() throws java.rmi.RemoteException;
}
