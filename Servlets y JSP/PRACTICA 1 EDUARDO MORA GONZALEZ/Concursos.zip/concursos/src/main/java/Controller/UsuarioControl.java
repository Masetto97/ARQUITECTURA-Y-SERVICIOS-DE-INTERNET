package Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Dao.UsuariosDao;
import Model.*;
import java.io.PrintWriter;
import javax.servlet.annotation.WebServlet;

@WebServlet(name = "registro", urlPatterns = {"/registro"})

public class UsuarioControl extends HttpServlet {

    private static final long serialVersionUID = 1L;

    public UsuarioControl() {
        super();

    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     * response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        response.getWriter().append("Served at: ").append(request.getContextPath());
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     * response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        try {
            String nombre = request.getParameter("nombre");
            String clave = request.getParameter("clave");
            String perfil = request.getParameter("perfil");
            Usuarios user = new Usuarios(nombre, clave, perfil);

            if (UsuariosDao.registrar(user)) {
                request.getRequestDispatcher("/registroGuardado.jsp").forward(request, response);
            } else {
                request.getRequestDispatcher("/ErrorRegistro.jsp").forward(request, response);
            }
        } finally {
            out.close();
        }

    }

}
