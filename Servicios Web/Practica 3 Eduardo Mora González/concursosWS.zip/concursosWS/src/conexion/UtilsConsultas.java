package conexion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UtilsConsultas {
	
	final static Connection con = Conexion.conectar();

	public static int ObtenerMaxId() {
		int numero = 0;
		try {
			String SQL = "Select Count(idConcurso) from participar.participaciones group by idConcurso ORDER BY Count(idConcurso) DESC Limit 1;";

			PreparedStatement st;
			st = con.prepareStatement(SQL);
			ResultSet num = st.executeQuery();

			while (num.next()) {
				numero = num.getInt("Count(idConcurso)");
			}

			return numero;

		} catch (SQLException e) {
			return 0;
		}
	}
}
