/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ubu.participar.Beans;

import com.ubu.participar.Dao.ConcursosDao;
import com.ubu.participar.Dao.FicherosDao;
import java.util.ArrayList;
import javax.inject.Named;
import javax.enterprise.context.Dependent;
import javax.enterprise.context.RequestScoped;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author HP Pavilion
 */
@Named(value = "fileDownloadBean")
@RequestScoped
public class FileDownloadBean {

    private String idFichero;
    private String titulo;
    private String ruta;

    public static String seleccion;

    public FileDownloadBean(String idFichero, String titulo) {
        this.idFichero = idFichero;
        this.titulo = titulo;
    }

    public String getIdFichero() {
        return idFichero;
    }

    public void setIdFichero(String idFichero) {
        this.idFichero = idFichero;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getRuta() {
        return ruta;
    }

    public void setRuta(String ruta) {
        this.ruta = ruta;
    }

    public String volver() {

        return "votar";
    }

    public static String getSeleccion() {
        return seleccion;
    }

    public static void setSeleccion(String seleccion) {
        FileDownloadBean.seleccion = seleccion;
    }

    public static ArrayList<FileDownloadBean> getFicheros() {
        return FicherosDao.listar(Votar.seleccionado);
    }

    @Override
    public String toString() {
        return "FileDownloadBean{" + "idFichero=" + idFichero + ", titulo=" + titulo + ", ruta=" + ruta + '}';
    }
    
    
}
