/**
 * Participacion.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package concursosWS;

public class Participacion  implements java.io.Serializable {
    private java.lang.String apodo;

    private java.lang.String descripcion;

    private java.lang.String ID_Participante;

    private java.lang.String ID_concurso;

    private java.lang.String ID_usuario;

    private java.lang.String titulo;

    private java.lang.String votos;

    public Participacion() {
    }

    public Participacion(
           java.lang.String apodo,
           java.lang.String descripcion,
           java.lang.String ID_Participante,
           java.lang.String ID_concurso,
           java.lang.String ID_usuario,
           java.lang.String titulo,
           java.lang.String votos) {
           this.apodo = apodo;
           this.descripcion = descripcion;
           this.ID_Participante = ID_Participante;
           this.ID_concurso = ID_concurso;
           this.ID_usuario = ID_usuario;
           this.titulo = titulo;
           this.votos = votos;
    }


    /**
     * Gets the apodo value for this Participacion.
     * 
     * @return apodo
     */
    public java.lang.String getApodo() {
        return apodo;
    }


    /**
     * Sets the apodo value for this Participacion.
     * 
     * @param apodo
     */
    public void setApodo(java.lang.String apodo) {
        this.apodo = apodo;
    }


    /**
     * Gets the descripcion value for this Participacion.
     * 
     * @return descripcion
     */
    public java.lang.String getDescripcion() {
        return descripcion;
    }


    /**
     * Sets the descripcion value for this Participacion.
     * 
     * @param descripcion
     */
    public void setDescripcion(java.lang.String descripcion) {
        this.descripcion = descripcion;
    }


    /**
     * Gets the ID_Participante value for this Participacion.
     * 
     * @return ID_Participante
     */
    public java.lang.String getID_Participante() {
        return ID_Participante;
    }


    /**
     * Sets the ID_Participante value for this Participacion.
     * 
     * @param ID_Participante
     */
    public void setID_Participante(java.lang.String ID_Participante) {
        this.ID_Participante = ID_Participante;
    }


    /**
     * Gets the ID_concurso value for this Participacion.
     * 
     * @return ID_concurso
     */
    public java.lang.String getID_concurso() {
        return ID_concurso;
    }


    /**
     * Sets the ID_concurso value for this Participacion.
     * 
     * @param ID_concurso
     */
    public void setID_concurso(java.lang.String ID_concurso) {
        this.ID_concurso = ID_concurso;
    }


    /**
     * Gets the ID_usuario value for this Participacion.
     * 
     * @return ID_usuario
     */
    public java.lang.String getID_usuario() {
        return ID_usuario;
    }


    /**
     * Sets the ID_usuario value for this Participacion.
     * 
     * @param ID_usuario
     */
    public void setID_usuario(java.lang.String ID_usuario) {
        this.ID_usuario = ID_usuario;
    }


    /**
     * Gets the titulo value for this Participacion.
     * 
     * @return titulo
     */
    public java.lang.String getTitulo() {
        return titulo;
    }


    /**
     * Sets the titulo value for this Participacion.
     * 
     * @param titulo
     */
    public void setTitulo(java.lang.String titulo) {
        this.titulo = titulo;
    }


    /**
     * Gets the votos value for this Participacion.
     * 
     * @return votos
     */
    public java.lang.String getVotos() {
        return votos;
    }


    /**
     * Sets the votos value for this Participacion.
     * 
     * @param votos
     */
    public void setVotos(java.lang.String votos) {
        this.votos = votos;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Participacion)) return false;
        Participacion other = (Participacion) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.apodo==null && other.getApodo()==null) || 
             (this.apodo!=null &&
              this.apodo.equals(other.getApodo()))) &&
            ((this.descripcion==null && other.getDescripcion()==null) || 
             (this.descripcion!=null &&
              this.descripcion.equals(other.getDescripcion()))) &&
            ((this.ID_Participante==null && other.getID_Participante()==null) || 
             (this.ID_Participante!=null &&
              this.ID_Participante.equals(other.getID_Participante()))) &&
            ((this.ID_concurso==null && other.getID_concurso()==null) || 
             (this.ID_concurso!=null &&
              this.ID_concurso.equals(other.getID_concurso()))) &&
            ((this.ID_usuario==null && other.getID_usuario()==null) || 
             (this.ID_usuario!=null &&
              this.ID_usuario.equals(other.getID_usuario()))) &&
            ((this.titulo==null && other.getTitulo()==null) || 
             (this.titulo!=null &&
              this.titulo.equals(other.getTitulo()))) &&
            ((this.votos==null && other.getVotos()==null) || 
             (this.votos!=null &&
              this.votos.equals(other.getVotos())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getApodo() != null) {
            _hashCode += getApodo().hashCode();
        }
        if (getDescripcion() != null) {
            _hashCode += getDescripcion().hashCode();
        }
        if (getID_Participante() != null) {
            _hashCode += getID_Participante().hashCode();
        }
        if (getID_concurso() != null) {
            _hashCode += getID_concurso().hashCode();
        }
        if (getID_usuario() != null) {
            _hashCode += getID_usuario().hashCode();
        }
        if (getTitulo() != null) {
            _hashCode += getTitulo().hashCode();
        }
        if (getVotos() != null) {
            _hashCode += getVotos().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Participacion.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://concursosWS/", "participacion"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("apodo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "apodo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descripcion");
        elemField.setXmlName(new javax.xml.namespace.QName("", "descripcion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ID_Participante");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ID_Participante"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ID_concurso");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ID_concurso"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ID_usuario");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ID_usuario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("titulo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "titulo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("votos");
        elemField.setXmlName(new javax.xml.namespace.QName("", "votos"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

	@Override
	public String toString() {
		return "Participacion [apodo=" + apodo + ", descripcion=" + descripcion + ", ID_Participante=" + ID_Participante
				+ ", ID_concurso=" + ID_concurso + ", ID_usuario=" + ID_usuario + ", titulo=" + titulo + ", votos="
				+ votos + "]";
	}
    
    

}
