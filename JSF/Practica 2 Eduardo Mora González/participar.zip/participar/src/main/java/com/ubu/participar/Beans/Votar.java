package com.ubu.participar.Beans;

import com.ubu.participar.Dao.FicherosDao;
import com.ubu.participar.Dao.ParticipantesDao;
import com.ubu.participar.Util.SessionUtils;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;

@ManagedBean
@SessionScoped
public class Votar implements Serializable {

    public static String seleccionado;
    public static String ficheroseleccionado;
    private String idFichero;
    private String titulo;
    private String ruta;

    public String getSeleccionado() {
        return seleccionado;
    }

    public void setSeleccionado(String seleccionado) {
        this.seleccionado = seleccionado;
    }

    public static String getFicheroseleccionado() {
        return ficheroseleccionado;
    }

    public static void setFicheroseleccionado(String ficheroseleccionado) {
        Votar.ficheroseleccionado = ficheroseleccionado;
    }

    public String getIdFichero() {
        return idFichero;
    }

    public void setIdFichero(String idFichero) {
        this.idFichero = idFichero;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getRuta() {
        return ruta;
    }

    public void setRuta(String ruta) {
        this.ruta = ruta;
    }

    public static ArrayList<Participar> getParticipantes() {

        return ParticipantesDao.listar(concursos.seleccion);

    }

    public static ArrayList<FileDownloadBean> getFicheros() {
        return FicherosDao.listar(Votar.seleccionado);
    }

    public String votar() {

        HttpSession session = SessionUtils.getSession();
        session.setAttribute("seleccionado", seleccionado);

        boolean valid = ParticipantesDao.existe(seleccionado);
        if (valid) {

            ParticipantesDao.votar(seleccionado);
            return "votar";
        }
        return "votar";
    }

    public String volver() {

        return "concursos";
    }

    public void downloadFile() {

        HttpSession session = SessionUtils.getSession();
        session.setAttribute("ficheroseleccionado", ficheroseleccionado);

        String ruta = FicherosDao.ObtenerFichero(ficheroseleccionado);

        File file = new File(ruta);
        HttpServletResponse response = (HttpServletResponse) FacesContext.getCurrentInstance().getExternalContext().getResponse();

        response.setHeader("Content-Disposition", "attachment;filename=FICHEROCONCURSANTE.txt");
        response.setContentLength((int) file.length());
        ServletOutputStream out = null;
        try {
            FileInputStream input = new FileInputStream(file);
            byte[] buffer = new byte[1024];
            out = response.getOutputStream();
            int i = 0;
            while ((i = input.read(buffer)) != -1) {
                out.write(buffer);
                out.flush();
            }
            FacesContext.getCurrentInstance().getResponseComplete();
        } catch (IOException err) {
            err.printStackTrace();
        } finally {
            try {
                if (out != null) {
                    out.close();
                }
            } catch (IOException err) {
                err.printStackTrace();
            }
        }

    }

}
