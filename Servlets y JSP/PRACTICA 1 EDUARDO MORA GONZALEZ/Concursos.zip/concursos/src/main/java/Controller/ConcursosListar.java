package Controller;

import Dao.ConcursosDao;
import Model.Concursos;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "ConcursosListar", urlPatterns = {"/ConcursosListar"})
public class ConcursosListar extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        try {
            ArrayList<Concursos> concursos = null;
            concursos = ConcursosDao.listar();

            if (!concursos.isEmpty()) {
                request.setAttribute("concursos", concursos);
                request.getRequestDispatcher("/Inicio.jsp").forward(request, response);

            } else {
                request.setAttribute("concursos", null);
                request.getRequestDispatcher("/ErrorCargar.jsp").forward(request, response);
            }
        } finally {
            out.close();
        }
    }

}
