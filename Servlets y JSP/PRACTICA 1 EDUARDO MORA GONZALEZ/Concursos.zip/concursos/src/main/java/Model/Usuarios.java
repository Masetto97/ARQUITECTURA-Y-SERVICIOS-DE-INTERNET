package Model;

import java.io.Serializable;

public class Usuarios implements Serializable {

    private String ID_usuario;
    private String login;
    private String password;
    private String perfil_acceso;

    public Usuarios() {
        this.ID_usuario = "";
        this.login = "";
        this.password = "";
        this.perfil_acceso = "";
    }

    public Usuarios(String login, String password, String perfil_acceso) {
        this.ID_usuario = "";
        this.login = login;
        this.password = password;
        this.perfil_acceso = perfil_acceso;
    }

    public String getID_usuario() {
        return ID_usuario;
    }

    public void setID_usuario(String iD_usuario) {
        ID_usuario = iD_usuario;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPerfil_acceso() {
        return perfil_acceso;
    }

    public void setPerfil_acceso(String perfil_acceso) {
        this.perfil_acceso = perfil_acceso;
    }

    @Override
    public String toString() {
        return "Usuarios{" + "ID_usuario=" + ID_usuario + ", login=" + login + ", password=" + password + ", perfil_acceso=" + perfil_acceso + '}';
    }

}
