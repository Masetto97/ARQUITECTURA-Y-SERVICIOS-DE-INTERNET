package com.ubu.participar.Beans;

import static com.ubu.participar.Beans.Login.id;
import com.ubu.participar.Dao.LoginDAO;
import com.ubu.participar.Dao.ParticipantesDao;
import com.ubu.participar.Util.SessionUtils;
import java.util.ArrayList;
import javax.inject.Named;
import javax.enterprise.context.Dependent;
import javax.servlet.http.HttpSession;

@Named(value = "Crear")
@Dependent
public class Crear {

    public static String ID_USUARIO;
    public static String ID_Part;
    public static String tit;
    public static String des;
    public static String ap;

    public String getID_USUARIO() {
        return ID_USUARIO;
    }

    public void setID_USUARIO(String ID_USUARIO) {
        Crear.ID_USUARIO = ID_USUARIO;
    }

    public String getID_Part() {
        return ID_Part;
    }

    public void setID_Part(String ID_Part) {
        this.ID_Part = ID_Part;
    }

    public String getTit() {
        return tit;
    }

    public void setTit(String tit) {
        this.tit = tit;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }

    public String getAp() {
        return ap;
    }

    public void setAp(String ap) {
        this.ap = ap;
    }

    public String continuar() {

        ID_USUARIO = LoginDAO.getID(Login.uname, Login.pwd);

        ID_Part = ParticipantesDao.obtener(concursos.seleccion, ID_USUARIO);

        HttpSession session = SessionUtils.getSession();
        session.setAttribute("tit", tit);
        session.setAttribute("des", des);
        session.setAttribute("ap", ap);

        if (ParticipantesDao.existe(ID_Part)) {
            if (ParticipantesDao.Actualizar(ID_Part, tit, des, ap)) {
                return "FileUpload";
            }

        } else {
            if (ParticipantesDao.Crear(tit, des, ap, concursos.seleccion, ID_USUARIO)) {
                return "FileUpload";
            }
        }

        return "Crear";
    }

    public String volver() {

        return "concursos";
    }
}
