package com.ubu.participar.Dao;

import com.ubu.participar.Beans.Participar;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ParticipantesDao {

    public static ArrayList<Participar> listar(String seleccion) {

        String ID_Participante;
        String titulo;
        String descripcion;
        String apodo;
        String ID_concurso;
        String ID_usuario;
        String votos;

        try {

            String SQL = "Select * from `participar`.`participaciones` where idConcurso = ? ;";

            Connection con = DataConnect.getConnection();
            PreparedStatement st;

            st = con.prepareStatement(SQL);

            st.setString(1, seleccion);

            System.out.print(st.toString());

            ResultSet resultado = st.executeQuery();

            ArrayList<Participar> lista = new ArrayList();
            Participar Participa;

            System.out.print(st.toString());
            while (resultado.next()) {

                ID_Participante = resultado.getString("id");
                titulo = resultado.getString("titulo");
                descripcion = resultado.getString("descripcion");
                apodo = resultado.getString("apodo");
                ID_concurso = resultado.getString("idConcurso");
                ID_usuario = resultado.getString("idUsuario");
                votos = resultado.getString("votosAcumulados");

                Participa = new Participar(titulo, titulo, descripcion, apodo, ID_concurso, ID_usuario, votos);
                Participa.setID_Participante(ID_Participante);

                lista.add(Participa);
            }
            return lista;

        } catch (SQLException e) {
            return null;
        }

    }

    public static boolean existe(String id) {
        try {
            String SQL = "Select * from `participar`.`participaciones` WHERE id = ?;";

            Connection con = DataConnect.getConnection();
            PreparedStatement st;
            st = con.prepareStatement(SQL);
            st.setString(1, id);

            System.out.print(st.toString());

            ResultSet rs = st.executeQuery();
            if (rs.next()) {

                return true;
            } else {
                return false;
            }

        } catch (SQLException e) {
            return false;

        }
    }

    public static boolean votar(String id) {

        try {

            String SQL = "UPDATE `participar`.`participaciones` SET `votosAcumulados` = votosAcumulados + 1 WHERE id = ?;";

            Connection con = DataConnect.getConnection();
            PreparedStatement st;
            st = con.prepareStatement(SQL);
            st.setString(1, id);

            System.out.print(st.toString());

            if (st.executeUpdate() > 0) {

                return true;
            } else {
                return false;
            }

        } catch (SQLException e) {
            return false;

        }
    }

    public static String obtener(String concurso, String usuario) {

        String ID_Participante;

        try {

            String SQL = "Select * from `participar`.`participaciones` where idConcurso = ? and idUsuario = ? ;";

            Connection con = DataConnect.getConnection();
            PreparedStatement st;

            st = con.prepareStatement(SQL);

            st.setString(1, concurso);
            st.setString(2, usuario);

            System.out.print(st.toString());

            ResultSet resultado = st.executeQuery();

            if (resultado.next()) {
                ID_Participante = resultado.getString("id");
                return ID_Participante;
            }

        } catch (SQLException e) {
            return null;
        }
        return null;

    }

    public static boolean Actualizar(String id, String tit, String des, String ap) {
        try {

            String SQL = "UPDATE `participar`.`participaciones` SET titulo = ? , descripcion = ?  , apodo = ? WHERE id = ?;";

            Connection con = DataConnect.getConnection();
            PreparedStatement st;
            st = con.prepareStatement(SQL);
            st.setString(1, tit);
            st.setString(2, des);
            st.setString(3, ap);
            st.setString(4, id);
            System.out.print(st.toString());

            if (st.executeUpdate() > 0) {

                return true;
            } else {
                return false;
            }

        } catch (SQLException e) {
            return false;

        }
    }

    public static boolean Crear(String tit, String des, String ap, String Concursos, String Usuario) {
        try {

            String SQL = " INSERT INTO  `participar`.`participaciones` (titulo, descripcion, apodo, idConcurso, idUsuario, votosAcumulados) VALUES (? , ? , ? , ? , ? , 0);";

            Connection con = DataConnect.getConnection();
            PreparedStatement st;
            st = con.prepareStatement(SQL);
            st.setString(1, tit);
            st.setString(2, des);
            st.setString(3, ap);
            st.setString(4, Concursos);
            st.setString(5, Usuario);

            System.out.print(st.toString());

            if (st.executeUpdate() > 0) {

                return true;
            } else {
                return false;
            }

        } catch (SQLException e) {
            return false;

        }
    }

}
