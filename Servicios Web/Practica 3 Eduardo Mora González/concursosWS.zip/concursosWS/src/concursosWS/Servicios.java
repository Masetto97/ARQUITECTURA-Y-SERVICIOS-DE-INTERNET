package concursosWS;

import javax.jws.WebService;
import javax.servlet.http.HttpSession;
import javax.xml.ws.WebServiceContext;
import javax.xml.ws.handler.MessageContext;

import org.eclipse.persistence.jpa.jpql.parser.DateTime;

import Interfaces.Concursos;
import Model.Concurso;
import Model.Participacion;
import conexion.Conexion;
import conexion.UtilsConsultas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName = "Servicios")
public class Servicios implements Concursos {

	// http://localhost:8080/concursosWS/Servicios?tester

	@Resource
	private WebServiceContext wsContext;

	final Connection con = Conexion.conectar();
	private ArrayList<String> consultas = new ArrayList();

	@WebMethod(operationName = "consultarNumeroParticipantes")
	public int consultarNumeroParticipantes(@WebParam(name = "idConcurso") int idConcurso) {

		int numero = 0;
		String SQL = "Select count(id) from `participar`.`participaciones` where idConcurso = ? ;";

		PreparedStatement st;
		try {
			st = con.prepareStatement(SQL);
			st.setString(1, String.valueOf(idConcurso));

			ResultSet resultado = st.executeQuery();

			while (resultado.next()) {

				numero = resultado.getInt("count(id)");

			}
		} catch (SQLException e) {

			e.printStackTrace();
		}

		consultas.add("consultarNumeroParticipantes(" + String.valueOf(idConcurso) + ")");
		return numero;
	}

	@WebMethod
	public List<Participacion> consultarParticipantes(int idConcurso) {
		String ID_Participante;
		String titulo;
		String descripcion;
		String apodo;
		String ID_concurso;
		String ID_usuario;
		String votos;

		try {

			String SQL = "Select * from `participar`.`participaciones` where idConcurso = ? ;";

			PreparedStatement st;

			st = con.prepareStatement(SQL);

			st.setString(1, String.valueOf(idConcurso));

			ResultSet resultado = st.executeQuery();

			List<Participacion> lista = new ArrayList();
			Participacion Participa;

			System.out.print(st.toString());
			while (resultado.next()) {

				ID_Participante = resultado.getString("id");
				titulo = resultado.getString("titulo");
				descripcion = resultado.getString("descripcion");
				apodo = resultado.getString("apodo");
				ID_concurso = resultado.getString("idConcurso");
				ID_usuario = resultado.getString("idUsuario");
				votos = resultado.getString("votosAcumulados");

				Participa = new Participacion(titulo, titulo, descripcion, apodo, ID_concurso, ID_usuario, votos);
				Participa.setID_Participante(ID_Participante);

				lista.add(Participa);
			}

			consultas.add("consultarParticipantes(" + String.valueOf(idConcurso) + ")");
			return lista;

		} catch (SQLException e) {
			return null;
		}

	}

	@WebMethod
	public String consultarGanador(int idConcurso) {
		String ganador = "";
		String SQL = "Select apodo, MAX(votosAcumulados) votosAcumulados from `participar`.`participaciones` where idConcurso = ? ;";

		PreparedStatement st;
		try {
			st = con.prepareStatement(SQL);
			st.setString(1, String.valueOf(idConcurso));

			ResultSet resultado = st.executeQuery();

			while (resultado.next()) {

				ganador = resultado.getString("apodo");

			}
		} catch (SQLException e) {

			e.printStackTrace();
		}

		consultas.add("consultarGanador(" + String.valueOf(idConcurso) + ")");
		return ganador;
	}

	@WebMethod
	public List<Concurso> consultarUltimos10Concursos() {
		int ID_concurso;
		String titulo;
		String objetivo;
		String bases;
		String premios;
		String plazo;
		String jurado;
		int ID_usuario;

		try {

			String SQL = "Select * From participar.concursos Order by ID DESC LIMIT 10;";

			PreparedStatement st;

			st = con.prepareStatement(SQL);

			System.out.print(st.toString());

			ResultSet resultado = st.executeQuery();

			List<Concurso> lista = new ArrayList();
			Concurso C;

			while (resultado.next()) {

				ID_concurso = resultado.getInt("id");
				titulo = resultado.getString("titulo");
				objetivo = resultado.getString("objetivo");
				bases = resultado.getString("bases");
				premios = resultado.getString("premios");
				plazo = resultado.getString("plazo");
				jurado = resultado.getString("jurado");
				ID_usuario = resultado.getInt("idUsuario");

				C = new Concurso(titulo, objetivo, bases, premios, plazo, jurado, ID_usuario);
				C.setID_concurso(ID_concurso);

				lista.add(C);
			}
			consultas.add("consultarUltimos10Concursos");
			return lista;

		} catch (SQLException e) {
			return null;
		}

	}

	@WebMethod
	public List<Concurso> consultarConcursosActivos(Date fechaInicio, Date fechaFin) {
		int ID_concurso;
		String titulo;
		String objetivo;
		String bases;
		String premios;
		String plazo;
		String jurado;
		int ID_usuario;
		try {

			String SQL = "Select * From participar.concursos where date(plazo) >= ? AND date(plazo) <= ?;";

			PreparedStatement st;

			st = con.prepareStatement(SQL);

			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
			String strFecha = sdf.format(fechaInicio);
			String strFecha2 = sdf.format(fechaInicio);

			st.setString(1, strFecha);
			st.setString(2, strFecha2);

			System.out.print(st.toString());

			ResultSet resultado = st.executeQuery();

			List<Concurso> lista = new ArrayList();
			Concurso C;

			while (resultado.next()) {

				ID_concurso = resultado.getInt("id");
				titulo = resultado.getString("titulo");
				objetivo = resultado.getString("objetivo");
				bases = resultado.getString("bases");
				premios = resultado.getString("premios");
				plazo = resultado.getString("plazo");
				jurado = resultado.getString("jurado");
				ID_usuario = resultado.getInt("idUsuario");

				C = new Concurso(titulo, objetivo, bases, premios, plazo, jurado, ID_usuario);
				C.setID_concurso(ID_concurso);

				lista.add(C);
			}
			consultas.add("consultarConcursosActivos(" + String.valueOf(fechaInicio) + " , " + String.valueOf(fechaFin)
					+ ")");
			return lista;

		} catch (SQLException e) {
			return null;
		}
	}

	@WebMethod
	public Concurso consultarConcursoConMasParticipantes() {
		int ID_concurso;
		String titulo;
		String objetivo;
		String bases;
		String premios;
		String plazo;
		String jurado;
		int ID_usuario;
		int numero = UtilsConsultas.ObtenerMaxId();
		try {
			String SQL = "select * from participar.concursos where id = ?;";

			PreparedStatement st;

			st = con.prepareStatement(SQL);
			st.setInt(1, numero);
			ResultSet resultado = st.executeQuery();

			Concurso C = null;

			while (resultado.next()) {

				ID_concurso = resultado.getInt("id");
				titulo = resultado.getString("titulo");
				objetivo = resultado.getString("objetivo");
				bases = resultado.getString("bases");
				premios = resultado.getString("premios");
				plazo = resultado.getString("plazo");
				jurado = resultado.getString("jurado");
				ID_usuario = resultado.getInt("idUsuario");

				C = new Concurso(titulo, objetivo, bases, premios, plazo, jurado, ID_usuario);
				C.setID_concurso(ID_concurso);
				consultas.add("consultarConcursoConMasParticipantes");
			}
			return C;
		} catch (SQLException e) {
			return null;
		}

	}

	@WebMethod
	public List<String> consultar() {
		consultas.add("consultar");
		return consultas;
	}
}
