package Interfaces;

import java.util.Date;
import java.util.List;

import Model.Concurso;
import Model.Participacion;

public interface Concursos {
	public List<Concurso> consultarUltimos10Concursos();

	public List<Concurso> consultarConcursosActivos(Date fechaInicio, Date fechaFin);

	public Concurso consultarConcursoConMasParticipantes();

	public int consultarNumeroParticipantes(int idConcurso);

	public List<Participacion> consultarParticipantes(int idConcurso);

	public String consultarGanador(int idConcurso);
}