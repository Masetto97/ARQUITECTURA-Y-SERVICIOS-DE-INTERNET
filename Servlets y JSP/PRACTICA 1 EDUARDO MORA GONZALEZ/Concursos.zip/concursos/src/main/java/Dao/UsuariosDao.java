package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import Model.Usuarios;

public class UsuariosDao {

    public UsuariosDao() {
        super();
    }

    public static boolean registrar(Usuarios user) {

        try {

            String SQL = "INSERT INTO `concursos`.`usuarios` (`login`, `password`, `perfilAcceso`) VALUES (?, ?, ?);";

            Connection con = Conexion.conectar();
            PreparedStatement st;

            st = con.prepareStatement(SQL);
            st.setString(1, user.getLogin());
            st.setString(2, user.getPassword());
            st.setString(3, user.getPerfil_acceso());

            if (st.executeUpdate() > 0) {
                return true;
            } else {
                return false;
            }

        } catch (SQLException e) {
            return false;
        }
    }

    public static ArrayList<Usuarios> listar() {

        try {

            String SQL = "Select * from `concursos`.`usuarios`;";

            Connection con = Conexion.conectar();
            PreparedStatement st;

            st = con.prepareStatement(SQL);

            ResultSet resultado = st.executeQuery();

            ArrayList<Usuarios> lista = null;
            Usuarios user;

            while (resultado.next()) {

                user = new Usuarios();
                user.setID_usuario(resultado.getString("id"));
                user.setLogin(resultado.getString("login"));
                user.setPassword(resultado.getString("password"));
                user.setPerfil_acceso(resultado.getString("perfilAcceso"));
                lista.add(user);
            }
            return lista;

        } catch (SQLException e) {
            return null;
        }

    }

    public static boolean consultar(String usuario, String clave) {
        try {

            String SQL = "Select * from `concursos`.`usuarios` Where login = ? and password = ? ;";

            Connection con = Conexion.conectar();
            PreparedStatement st;
            st = con.prepareStatement(SQL);

            st.setString(1, usuario);
            st.setString(2, clave);
            ResultSet rs = st.executeQuery();
            if (rs.next()) {

                return true;
            } else {
                return false;
            }

        } catch (SQLException e) {
            return false;

        }
    }

    public static String obtener_id(String usuario) {
        try {

            String SQL = "Select * from `concursos`.`usuarios` Where login = ?;";
            String id = "";
            Connection con = Conexion.conectar();
            PreparedStatement st;
            st = con.prepareStatement(SQL);

            st.setString(1, usuario);

            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                id = rs.getString("id");
                return id;
            } else {
                return id;
            }

        } catch (SQLException e) {
            return null;

        }
    }

}
